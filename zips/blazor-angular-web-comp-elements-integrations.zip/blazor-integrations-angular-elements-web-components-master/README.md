# Blazor Integrations - Building Bridges between JavaScript and WebAssembly Universes
## Using an Angular Elements Web Component Custom Element in a Blazor WebAssembly (WASM) Application

Please see the accompanying article at https://www.thinktecture.com/blazor/integrations/angular-elements-web-components/