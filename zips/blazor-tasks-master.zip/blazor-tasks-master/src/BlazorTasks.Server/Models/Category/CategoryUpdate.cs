using System;

namespace BlazorTasks.Server.Models
{
	public class CategoryUpdate
	{
        public string Name { get; set; }

		public string Color { get; set; }
	}
}