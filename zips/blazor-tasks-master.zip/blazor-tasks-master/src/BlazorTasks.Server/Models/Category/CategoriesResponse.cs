using BlazorTasks.Server.Models;

namespace BlazorTasks.Server
{
	public class CategoriesResponse : Collection<Category>
	{	
	}
}