using BlazorTasks.Server.Models;

namespace BlazorTasks.Server
{
	public class TodoTasksResponse : Collection<TodoTask>
	{	
	}
}