using System;

namespace BlazorTasks.Client.Models
{
	public class CategoryForm
	{
		public string Name { get; set; }
		public string Color { get; set; } = "#2FA2B6";
	}
}