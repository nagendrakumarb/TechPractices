using System;

namespace BlazorTasks.Client.Models
{
	public class TodoTaskForm
	{
		public string Name { get; set; }
		public string CategoryId { get; set; }
	}
}