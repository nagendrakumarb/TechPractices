namespace BlazorTasks.Client.Models
{
	public abstract class Link
	{
		public string Href { get; set; }
	}
}