namespace WebApi.Models
{
    public class RevokeTokenRequest
    {
        public string Token { get; set; }
    }
}