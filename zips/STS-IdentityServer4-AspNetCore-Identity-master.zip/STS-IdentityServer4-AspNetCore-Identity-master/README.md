# STS-IdentityServer4-AspNetCore-Identity
A Security Token Service project using IdentityServer4 and Asp.Net Core Identity.
